#cd /var/www/app/server/dist/
#sudo forever stop server.js
#sudo forever stopall
forever stopall